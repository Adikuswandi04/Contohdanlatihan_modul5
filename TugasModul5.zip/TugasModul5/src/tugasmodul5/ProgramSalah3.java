package tugasmodul5;

public class ProgramSalah3 {
       public static void main (String[] args){
         int x = 5;
         int y = 10;
         
         if(x < y){
            System.out.println("X lebih kecil dari Y");
         }else{
             System.out.println("X lebih besar dari y");
         }
         
         int z = x+y;
         
         for (int i = 0; i <= z; i++){
         System.out.print(i+" ");
         }
     } 
}
