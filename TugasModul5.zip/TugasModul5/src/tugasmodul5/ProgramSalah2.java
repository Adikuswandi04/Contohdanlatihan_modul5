/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugasmodul5;

/**
 *
 * @author Mahasiswa
 */
public class ProgramSalah2 {
     public static void main (String[] args){
         int x = 5;
        if( x > 0 )
            System.out.println("Angka positif");
        else
            System.out.println("Angka negatif");
     }
}
